import { Component } from '@angular/core';
import {smsService} from './sms/sms.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[smsService]
})
export class AppComponent {
  title = 'capbook';
}
