import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { login} from "./login";
import {userProfile} from "./userprofile"

const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class loginService{
private postlogin='http://localhost:8083/profileCreation/login';
private postUser='http://localhost:8083/profileCreation/profile';
private changepsswd='http://localhost:8083/profileCreation/changepwd';
private Login:login[];
private uprofile:userProfile[];
constructor(private _http:HttpClient){

} 
 
postSms(login1:login):Observable<login>
{
return this._http.post<login>(this.postlogin,login1,{})
} 
 
postuser(userp:userProfile):Observable<userProfile>
{
return this._http.post<userProfile>(this.postlogin,userp,{})
} 
// changePaswd(login1:login):Observable<login>
// {
// return this._http.post<login>(this.postlogin,login1,{})
// } 
}