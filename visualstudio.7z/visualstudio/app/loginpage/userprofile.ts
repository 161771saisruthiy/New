export class userProfile{
    username:string;
    dob:Date;
    email:string;
    password:string;
    gender:string;
}