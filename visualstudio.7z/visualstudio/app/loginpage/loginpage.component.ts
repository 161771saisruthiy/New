import { Component, OnInit } from '@angular/core';

import { login } from './login';
import { loginService } from './loginservice';

@Component({
  selector: 'pm-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  lgn:login=new login();
  constructor(private lgnservice:loginService) { }

  ngOnInit() {
  //  this
  }

}
