export class login{
    email:string;
    password:string;
}