import { Component } from "@angular/core";

@Component({
    selector: 'atla-root',
    template:`<div>
    <h1>{{Atla}}</h1>
    <h1>{{Atla1}}</h1>
    </div>`

})
export class Atlane {
    Atla: string='Hey! How are you?';
    Atla1: string='Wassup';
}
