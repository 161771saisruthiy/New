export class friend{
    
    senderId:number;
    receiverId:number;
    status:string;
    profilepic:Blob;

}