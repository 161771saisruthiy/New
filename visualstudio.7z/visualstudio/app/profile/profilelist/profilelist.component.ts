import { Component, OnInit } from '@angular/core';
import { Profile } from './profile.component';
import { friend } from './friend';


@Component({
  selector: 'app-profilelist',
  templateUrl: './profilelist.component.html',
  styleUrls: ['./profilelist.component.css']
})
export class ProfilelistComponent implements OnInit {


  button:string="Add Friend"
   frnd=new friend();
//   profileList: Profile[] = [{
    
//     fullName: "Mark Zuckerberg",
//     photoPath:"assets/images/dp.jpg",
//     description: "Software Engineer",
//     relationship: "Single",
//     mobileNo: 7306447896,
//     status:"Approve"
    
  
//   }
// ]

switch () {
case 'Accept':{
  this.button="Friends"
  break;
}
case
}



  

  constructor() { }

  ngOnInit() {

  }

}
