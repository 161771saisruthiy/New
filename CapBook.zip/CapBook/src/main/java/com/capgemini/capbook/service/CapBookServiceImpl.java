package com.capgemini.capbook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capbook.bean.ChangePassword;
import com.capgemini.capbook.bean.Friend;
import com.capgemini.capbook.bean.Login;
import com.capgemini.capbook.bean.UserProfile;
import com.capgemini.capbook.dao.IFriendDao;
import com.capgemini.capbook.dao.ILoginDao;
import com.capgemini.capbook.dao.IPasswdDao;
import com.capgemini.capbook.dao.IUserProfileDao;

@Service("friendservice")
public class CapBookServiceImpl implements ICapBookService{

	@Autowired
	private IFriendDao frienddao;
	@Autowired
	private IUserProfileDao userProfile;
	@Autowired
	private ILoginDao loginDao;
	@Autowired
	private IPasswdDao psswdDao;
	

	@Override
	public List<Friend> saveFriend(Friend friend) {
		
		frienddao.save(friend);
		
		return frienddao.findAll();
		
		
	}

	@Override
	public List<Friend> getFriend() {
		
		return frienddao.findAll();
		 
		
	}

	@Override
	public List<UserProfile> saveUser(UserProfile userprofile) {
		userProfile.save(userprofile);
		return userProfile.findAll();
		
	}

	@Override
	public List<Login> savelogin(Login login) {
	
		loginDao.save(login);
		
		return loginDao.findAll();
	}

	@Override
	public List<ChangePassword> savepsswrd(ChangePassword changepsswd) {
		psswdDao.save(changepsswd);
		return psswdDao.findAll();
	}

	@Override
	public List<Login> getLoginDetails() {
		
		return loginDao.findAll();
	}

	@Override
	public List<ChangePassword> getPsswrdDetails() {
		// TODO Auto-generated method stub
		return psswdDao.findAll();
	}

	@Override
	public List<UserProfile> getUserDetails() {
		// TODO Auto-generated method stub
		return userProfile.findAll();
	}

	
}
